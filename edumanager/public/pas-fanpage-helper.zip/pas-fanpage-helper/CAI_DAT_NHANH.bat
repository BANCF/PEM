@echo off
chcp 65001 >nul
setlocal
set "TARGET=%LOCALAPPDATA%\PASFanpageHelper"
echo ============================================================
echo   CAI DAT NHANH - PAS FANPAGE HELPER
echo ============================================================
echo.
if not exist "%~dp0fanpage-extension\manifest.json" (
  echo [LOI] Khong tim thay thu muc fanpage-extension ben canh file nay!
  echo Vui long giai nen toan bo file ZIP truoc khi chay.
  pause
  exit /b 1
)
if exist "%TARGET%" rmdir /s /q "%TARGET%"
xcopy /E /I /Y "%~dp0fanpage-extension" "%TARGET%" >nul
echo %TARGET%| clip
echo [1/2] Da chep extension vao: %TARGET%
echo       (Da tu dong COPY duong dan nay vao bo nho tam!)
echo.
echo [2/2] Dang mo Chrome -^> Trang quan ly Extension...
start "" chrome "chrome://extensions"
echo.
echo HUONG DAN 3 GIAY TREN CHROME:
echo   1. Bat "Che do danh cho nha phat trien" (goc phai tren)
echo   2. Bam "Tai tien ich da giai nen" (Load unpacked)
echo   3. Bam Ctrl+V vao o chon thu muc roi bam Enter!
echo   4. Quay lai trang PEM bam "Ket noi tu dong".
echo.
pause
